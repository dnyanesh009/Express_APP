# sample-express-app
Sample express application which displays  content from HTML template. 
